package com.hoony.msa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableConfigurationProperties(MsaConfig.class)
public class MsaServiceController {
	
	@Autowired
	private MsaConfig msaConfig;
	
	@Value("${msaconfig.greeting}")
	private String greeting;
	
	@RequestMapping(value="/accounts", method=RequestMethod.GET)
	public String accounts() {
		return greeting + " / 11 " + msaConfig.getGreeting();
	}
}
