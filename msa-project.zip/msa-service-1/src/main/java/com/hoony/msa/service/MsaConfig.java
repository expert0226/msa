package com.hoony.msa.service;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix="msaconfig")
public class MsaConfig {

	private String greeting;
	
	public String getGreeting() {
		return greeting;
	}
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
}
