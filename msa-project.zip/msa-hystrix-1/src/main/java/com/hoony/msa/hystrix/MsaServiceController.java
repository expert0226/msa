package com.hoony.msa.hystrix;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class MsaServiceController {
	
	@HystrixCommand(fallbackMethod = "getHystrixFallback")
	@RequestMapping(value="/hystrix", method=RequestMethod.GET)
	public String getHystrix() {
		return "hystrix";
	}
	public String getHystrixFallback() {
		return "getHystrixFallback";
	}
}
